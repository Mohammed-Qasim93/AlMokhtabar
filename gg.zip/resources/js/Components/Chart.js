import React from "react";

export default function Chart({}) {
    return <div className="">ojopj</div>;
}
